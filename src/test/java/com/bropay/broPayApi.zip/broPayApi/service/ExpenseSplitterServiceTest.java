package com.bropay.broPayApi.service;

import com.bropay.broPayApi.dto.LineItemDTO;
import com.bropay.broPayApi.dto.SplitRequestDTO;
import com.bropay.broPayApi.dto.SplitSummaryDTO;
import com.bropay.broPayApi.model.ConnectionStatus;
import com.bropay.broPayApi.model.Customer;
import com.bropay.broPayApi.model.SplitType;
import com.bropay.broPayApi.model.UserConnection;
import com.bropay.broPayApi.repository.CustomerRepository;
import com.bropay.broPayApi.repository.UserConnectionRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.ArgumentMatchers.eq;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExpenseSplitterServiceTest {

    @Mock
    private UserConnectionRepository userConnectionRepository;

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private ExpenseSplitterService splitterService;

    private final String initiatorId = "1";
    private Customer initiator;
    private Customer friend1;
    private Customer friend2;

    @BeforeEach
    void setUp() {
        // ✅ Define Customers
        initiator = new Customer();
        initiator.setId(initiatorId);
        initiator.setName("Initiator");

        friend1 = new Customer();
        friend1.setId("2");
        friend1.setName("Friend One");

        friend2 = new Customer();
        friend2.setId("3");
        friend2.setName("Friend Two");

        // ✅ Mock CustomerRepository (use Strings, not Longs)
        Mockito.when(customerRepository.findById("1")).thenReturn(Optional.of(initiator));
        Mockito.when(customerRepository.findById("2")).thenReturn(Optional.of(friend1));
        Mockito.when(customerRepository.findById("3")).thenReturn(Optional.of(friend2));

        // ✅ Mock UserConnectionRepository for both friends
        mockAcceptedConnection(initiator, friend1);
        mockAcceptedConnection(initiator, friend2);
    }

    private void mockAcceptedConnection(Customer requester, Customer recipient) {
        UserConnection connection = new UserConnection();
        connection.setRequester(requester);
        connection.setRecipient(recipient);
        connection.setStatus(ConnectionStatus.ACCEPTED);

        Mockito.when(userConnectionRepository.findByRequesterAndRecipientAndStatus(
            eq(requester), eq(recipient), eq(ConnectionStatus.ACCEPTED)
        )).thenReturn(Optional.of(connection));

        Mockito.when(userConnectionRepository.findByRequesterAndRecipientAndStatus(
            eq(recipient), eq(requester), eq(ConnectionStatus.ACCEPTED)
        )).thenReturn(Optional.of(connection));
    }

    @Test
    void testEqualSplit() {
        List<LineItemDTO> items = List.of(
            new LineItemDTO("Apple", "$6.00", "1"),
            new LineItemDTO("Orange", "$4.00", "1")
        );

        List<SplitRequestDTO> participants = List.of(
            new SplitRequestDTO("Alice", null, null, "2"),
            new SplitRequestDTO("Bob", null, null, "3")
        );

        List<SplitSummaryDTO> result = splitterService.calculateSplits(
            initiatorId, items, participants, SplitType.EQUAL
        );

        assertEquals(2, result.size());
        assertEquals(5.0, result.get(0).getAmountOwed());
        assertEquals(5.0, result.get(1).getAmountOwed());
    }

    @Test
    void testPercentageSplit() {
        List<LineItemDTO> items = List.of(
            new LineItemDTO("Mango", "$10.00", "1")
        );

        List<SplitRequestDTO> participants = List.of(
            new SplitRequestDTO("Alice", 60.0, null, "2"), // ✅ percentage added
            new SplitRequestDTO("Bob", 40.0, null, "3")   // ✅ percentage added
        );

        List<SplitSummaryDTO> result = splitterService.calculateSplits(
            initiatorId, items, participants, SplitType.PERCENTAGE
        );

        assertEquals(6.0, result.get(0).getAmountOwed());
        assertEquals(4.0, result.get(1).getAmountOwed());
    }

    @Test
    void testZeroPriceItems() {
        List<LineItemDTO> items = List.of(
            new LineItemDTO("Free Sample", "$0.00", "1")
        );

        List<SplitRequestDTO> participants = List.of(
            new SplitRequestDTO("Alice", null, null, "2"),
            new SplitRequestDTO("Bob", null, null, "3")
        );

        List<SplitSummaryDTO> result = splitterService.calculateSplits(
            initiatorId, items, participants, SplitType.EQUAL
        );

        assertEquals(0.0, result.get(0).getAmountOwed());
        assertEquals(0.0, result.get(1).getAmountOwed());
    }
}
