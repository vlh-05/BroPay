package com.bropay.broPayApi.controller;

import com.bropay.broPayApi.dto.SplitSummaryDTO;
import com.bropay.broPayApi.model.SplitType;
import com.bropay.broPayApi.security.JwtTokenUtil;
import com.bropay.broPayApi.service.ExpenseSplitterService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@TestPropertySource(properties = {
    "jwt.secret=TestSecretKeyThatIsAtLeastSixtyFourCharactersLongForHS512Algorithm123!",
    "jwt.expiration=86400000"
})
@AutoConfigureMockMvc
public class SplitControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    // ✅ Inject real JwtTokenUtil to generate a valid JWT
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @MockBean
    private ExpenseSplitterService expenseSplitterService;

    @Test
    void testPercentageSplit() throws Exception {
        // 🧪 Mock result returned by service
        List<SplitSummaryDTO> mockResult = List.of(
            new SplitSummaryDTO("Alice", 3.6),
            new SplitSummaryDTO("Bob", 2.4)
        );

        // ✅ Mock the service method
        when(expenseSplitterService.calculateSplits(
            anyString(), anyList(), anyList(), eq(SplitType.PERCENTAGE)))
            .thenReturn(mockResult);
        // 📦 JSON request
        String requestJson = """
        {
          "initiatorId": "1",
          "splitType": "PERCENTAGE",
          "participants": [
            { "participantName": "Alice", "sharePercentage": 60.0, "participantId": "2" },
            { "participantName": "Bob", "sharePercentage": 40.0, "participantId": "3" }
          ],
          "lineItems": [
            { "description": "Milk", "price": "4.00", "quantity": "1" },
            { "description": "Bread", "price": "2.00", "quantity": "1" }
          ]
        }
        """;


        // ✅ Generate a valid JWT for userId=1
        String token = jwtTokenUtil.generateToken(1L, "test@example.com", "USER");


        // 🚀 Test the endpoint with a real JWT
        mockMvc.perform(post("/api/split/compute")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + token)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].participantName", is("Alice")))
                .andExpect(jsonPath("$[0].amountOwed", is(3.6)))
                .andExpect(jsonPath("$[1].participantName", is("Bob")))
                .andExpect(jsonPath("$[1].amountOwed", is(2.4)));
    }
}
